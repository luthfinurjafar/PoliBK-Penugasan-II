<?php
session_start();

if (!isset($_SESSION['id_pasien'])) {
    header("Location: login.php");
    exit();
}

$mysqli = new mysqli("localhost", "root", "", "poli_bk");

if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

$id_pasien = $_SESSION['id_pasien'];
$query = "SELECT dp.id, dp.id_pasien, dp.id_jadwal, dp.keluhan, dp.no_antrian, dp.tanggal, dp.status_periksa, 
                 dp.jadwal_periksa, dp.jam_mulai, dp.jam_selesai, 
                 p.nama_poli, d.nama AS nama_dokter 
          FROM daftar_poli dp
          JOIN jadwal_dokter jd ON dp.id_jadwal = jd.id
          JOIN dokter d ON jd.id_dokter = d.id
          JOIN poli p ON d.id_poli = p.id
          WHERE dp.id_pasien = '$id_pasien' 
          ORDER BY dp.tanggal DESC";
$result = mysqli_query($mysqli, $query);

if (!$result) {
    die("Query gagal: " . mysqli_error($mysqli));
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Riwayat Pendaftaran</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            background-color: #f0f8ff;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .container {
            flex: 1;
            max-width: 100%;
            background: white;
            border-radius: 15px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 30px;
            margin: 30px auto;
        }
        .footer {
            background-color: #0056b3;
            color: white;
            padding: 20px;
            text-align: center;
            margin-top: 50px;
        }
        .footer a {
            color: white;
        }
        .footer a:hover {
            color: #c82333;
        }
        .header {
            background-color: #0056b3;
            color: white;
            padding: 20px;
            text-align: center;
            margin-bottom: 30px;
            border-radius: 15px 15px 0 0;
        }
        .card-container {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
        }
        .card {
            flex: 1;
            margin: 0 10px;
        }
        .table {
            width: 100%;
            margin-bottom: 1rem;
        }
        th, td {
            text-align: center;
            vertical-align: middle;
        }
        th {
            background-color: #0056b3;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>Riwayat Pendaftaran</h1>
    </div>

    <div class="container mt-5">
        
        <div class="card-body">
            <table class="table table-striped table-bordered table-responsive">
                <thead>
                    <tr>
                        <th>No Antrian</th>
                        <th>Tanggal Daftar</th>
                        <th>Tanggal Periksa</th>
                        <th>Jam Mulai</th>
                        <th>Jam Selesai</th>
                        <th>Poli</th>
                        <th>Dokter</th>
                        <th>Keluhan</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                        <tr>
                            <td><?= $row['no_antrian']; ?></td>
                            <td><?= $row['tanggal']; ?></td>
                            <td><?= $row['jadwal_periksa']; ?></td>
                            <td><?= $row['jam_mulai']; ?></td>
                            <td><?= $row['jam_selesai']; ?></td>
                            <td><?= $row['nama_poli']; ?></td>
                            <td><?= $row['nama_dokter']; ?></td>
                            <td><?= $row['keluhan']; ?></td>
                            <td><?= $row['status_periksa']; ?></td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
            <a href="dashboardPasien.php" class="btn btn-secondary">Kembali ke Dashboard</a>
        </div>
    </div>

    <div class="footer">
        <h5>&copy; 2024 Sistem Layanan Kesehatan</h5>
        <p><a href="privacy.php">Kebijakan Privasi</a> | <a href="terms.php">Syarat dan Ketentuan</a></p>
    </div>
</body>
</html> 