<?php
session_start();
include_once("koneksi.php");

// Cek apakah pengguna sudah login sebagai dokter
if (!isset($_SESSION['id']) || !isset($_SESSION['nama'])) {
    echo "<script>
        alert('Anda harus login terlebih dahulu');
        window.location.href='loginDokter.php';
    </script>";
    exit;
}

$id_dokter = $_SESSION['id'];  // Ambil ID dokter dari session

// Aksi hapus pasien
if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];
    $delete_pasien = mysqli_query($mysqli, "DELETE FROM daftar_poli WHERE id = '$id'");
    if ($delete_pasien) {
        echo "<script>
            alert('Pasien berhasil dihapus');
            window.location.href='periksa.php';
        </script>";
    } else {
        echo "<script>
            alert('Gagal menghapus pasien');
        </script>";
    }
}

// Tangani pengiriman form
if (isset($_POST['submit'])) {
    $catatan = mysqli_real_escape_string($mysqli, $_POST['catatan']);
    $resep = $_POST['resep'];
    $biaya_periksa = 150000; // Biaya pemeriksaan tetap
    $biaya_obat = 0;

    // Hitung biaya obat berdasarkan resep yang dipilih
    foreach ($resep as $id_obat) {
        $obatData = mysqli_query($mysqli, "SELECT harga FROM obat WHERE id = '$id_obat'");
        $hargaObat = mysqli_fetch_assoc($obatData)['harga'];
        $biaya_obat += $hargaObat;
    }

    // Total biaya (biaya pemeriksaan + biaya obat)
    $total_biaya = $biaya_periksa + $biaya_obat;
    $tgl_periksa = date('Y-m-d H:i:s');

    // Ambil ID pasien dari parameter URL
    $id_daftar_poli = $_GET['id'];

    // Simpan ke tabel periksa
    $insertPeriksa = mysqli_query($mysqli, "
        INSERT INTO periksa (id_daftar_poli, tgl_periksa, catatan, biaya_periksa, biaya_obat, total_biaya) 
        VALUES ('$id_daftar_poli', '$tgl_periksa', '$catatan', '$biaya_periksa', '$biaya_obat', '$total_biaya')
    ");

    // Perbarui status pasien di tabel daftar_poli setelah berhasil menyimpan pemeriksaan
    if ($insertPeriksa) {
        $updateStatus = mysqli_query($mysqli, "UPDATE daftar_poli SET status_periksa = 'sudah diperiksa' WHERE id = '$id_daftar_poli'");
    }

    if ($insertPeriksa && $updateStatus) {
        // Redirect ke halaman rincian biaya
        header("Location: biayaPeriksa.php?id=$id_daftar_poli&biaya_periksa=$total_biaya&catatan=" . urlencode($catatan));
        exit;
    } else {
        echo "<script>
            alert('Terjadi kesalahan saat menyimpan data pemeriksaan');
        </script>";
    }
}

// Query untuk mengambil pasien yang terdaftar pada poli dokter yang login
$query = "
    SELECT daftar_poli.id, daftar_poli.id_pasien, daftar_poli.id_jadwal, daftar_poli.keluhan, 
           daftar_poli.no_antrian, daftar_poli.tanggal, daftar_poli.status_periksa, 
           daftar_poli.jadwal_periksa, daftar_poli.jam_mulai, daftar_poli.jam_selesai, 
           daftar_poli.poli, daftar_poli.dokter, pasien.nama AS nama 
    FROM daftar_poli 
    JOIN pasien ON daftar_poli.id_pasien = pasien.id
    JOIN jadwal_dokter ON daftar_poli.id_jadwal = jadwal_dokter.id
    WHERE jadwal_dokter.id_dokter = '$id_dokter'
    ORDER BY daftar_poli.no_antrian ASC
";

// Eksekusi query
$result = mysqli_query($mysqli, $query);


?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Periksa Pasien - Poliklinik</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Segoe+UI:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            margin: 0;
            padding: 0;
            padding-bottom: 60px; /* Memberikan ruang untuk footer */
            background-color: #f0f8ff;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .header {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            background-color: #0056b3;
            color: white;
            padding: 20px;
            text-align: center;
            z-index: 1000; /* Pastikan header di atas konten lainnya */
        }

        .footer {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background-color: #0056b3;
            color: white;
            padding: 20px;
            text-align: center;
            z-index: 1000; /* Pastikan footer di atas konten lainnya */
        }

        .container {
            margin-top: 80px; /* Memberikan ruang untuk header */
            margin-bottom: 80px; /* Memberikan ruang untuk footer */
            display: flex;
            justify-content: center; /* Mengatur konten agar berada di tengah */
            align-items: center; /* Mengatur konten agar berada di tengah secara vertikal */
            flex-direction: column; /* Mengatur arah konten menjadi kolom */
        }

        .card {
            border-radius: 15px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border: none;
            margin-bottom: 30px;
            background: white;
        }

        .card-header {
            background-color: #0056b3;
            color: white;
            border-radius: 15px 15px 0 0 !important;
            padding: 15px 20px;
        }

        .table {
            width: 100%; /* Mengatur lebar tabel menjadi 100% */
            margin: 20px 0; /* Memberikan jarak atas dan bawah untuk tabel */
            border-collapse: collapse; /* Menghilangkan jarak antara border tabel */
        }

        .table th, .table td {
            padding: 15px; /* Memberikan padding pada sel tabel */
            text-align: left; /* Mengatur teks di dalam sel tabel ke kiri */
        }

        .table th {
            background-color: #0056b3; /* Warna latar belakang untuk header tabel */
            color: white; /* Warna teks untuk header tabel */
        }

        .table-bordered {
            border: 1px solid #dee2e6; /* Border untuk tabel */
        }

        .table-bordered th, .table-bordered td {
            border: 1px solid #dee2e6; /* Border untuk sel tabel */
        }

        /* Atur lebar kolom */
        .table th:nth-child(1), .table td:nth-child(1) { width: 5%; text-align: center; } /* No Antrian */
        .table th:nth-child(2), .table td:nth-child(2) { width: 20%; } /* Nama Pasien */
        .table th:nth-child(3), .table td:nth-child(3) { width: 10%; text-align: center; } /* No. Antrian */
        .table th:nth-child(4), .table td:nth-child(4) { width: 25%; } /* Keluhan */
        .table th:nth-child(5), .table td:nth-child(5) { width: 10%; text-align: center; } /* Hari */
        .table th:nth-child(6), .table td:nth-child(6) { width: 15%; text-align: center; } /* Jam Periksa */
        .table th:nth-child(7), .table td:nth-child(7) { width: 10%; text-align: center; } /* Status */
        .table th:nth-child(8), .table td:nth-child(8) { width: 10%; text-align: center; } /* Aksi */

        .badge {
            padding: 8px 15px;
            border-radius: 50px;
            font-weight: 500;
        }

        .badge-warning {
            background-color: #ffc107;
            color: #000;
        }

        .badge-success {
            background-color: #28a745;
            color: white;
        }

        .btn {
            border-radius: 50px;
            padding: 8px 20px;
            font-weight: 500;
            transition: all 0.3s ease;
            margin: 0 5px;
        }

        .btn:hover {
            transform: translateY(-2px);
        }

        .btn-success {
            background-color: #f8f9fa;
            border: none;
        }

        .btn-danger {
            background-color: #dc3545;
            border: none;
        }

        .back-link {
            color: #0056b3;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            margin: 20px 0;
            font-weight: 500;
        }

        .back-link:hover {
            color: #003d82;
        }

        .footer {
            margin-top: 50px;
        }

        .footer a {
            color: white;
            text-decoration: none;
        }

        .footer a:hover {
            color: #c82333;
        }

        @media (max-width: 768px) {
            .container {
                padding: 15px;
            }
            
            .btn {
                padding: 6px 15px;
                font-size: 14px;
                margin-bottom: 5px;
            }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <div class="header">
        <h1>Daftar Pasien</h1>
        <p>Kelola daftar pasien yang perlu diperiksa</p>
       
    </div>

    <div class="container">
        <a href="berandaDokter.php" class="back-link">
            <i class="fas fa-arrow-left"></i> Kembali ke Dashboard
        </a>

        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Daftar Pasien yang Terdaftar</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Nama Pasien</th>
                                <th>No. Antrian</th>
                                <th>Poli</th>
                                <th>Dokter</th>
                                <th>Keluhan</th>
                                <th>Tanggal Pendaftaran</th>
                                <th>Jadwal Periksa</th>
                                <th>Jam Mulai</th>
                                <th>Jam Selesai</th>
                                <th>Status Periksa</th>
                                
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            // Query untuk mengambil pasien yang terdaftar pada poli dokter yang login
                            $query = "
                                SELECT daftar_poli.id, daftar_poli.id_pasien, daftar_poli.id_jadwal, daftar_poli.keluhan, 
                                       daftar_poli.no_antrian, daftar_poli.tanggal, daftar_poli.status_periksa, 
                                       daftar_poli.jadwal_periksa, daftar_poli.jam_mulai, daftar_poli.jam_selesai, 
                                       daftar_poli.poli, daftar_poli.dokter, pasien.nama AS nama 
                                FROM daftar_poli 
                                JOIN pasien ON daftar_poli.id_pasien = pasien.id
                                JOIN jadwal_dokter ON daftar_poli.id_jadwal = jadwal_dokter.id
                                WHERE jadwal_dokter.id_dokter = '$id_dokter'
                                ORDER BY daftar_poli.no_antrian ASC
                            ";

                            // Eksekusi query
                            $result = mysqli_query($mysqli, $query);

                            // Cek apakah query berhasil
                            if (!$result) {
                                echo "<tr><td colspan='12' class='text-center'>Gagal mengambil data pasien: " . mysqli_error($mysqli) . "</td></tr>";
                            } elseif (mysqli_num_rows($result) == 0) {
                                echo "<tr><td colspan='12' class='text-center'>Tidak ada pasien yang terdaftar.</td></tr>";
                            } else {
                                $no = 1;
                                while ($row = mysqli_fetch_array($result)) {
                                    echo "<tr>
                                            <td>{$no}</td>
                                            <td>{$row['nama']}</td>
                                            <td>{$row['no_antrian']}</td>
                                            <td>{$row['poli']}</td>
                                            <td>{$row['dokter']}</td>
                                            <td>{$row['keluhan']}</td>
                                            <td>{$row['tanggal']}</td>
                                            <td>{$row['jadwal_periksa']}</td>
                                            <td>{$row['jam_mulai']}</td>
                                            <td>{$row['jam_selesai']}</td>
                                            <td>{$row['status_periksa']}</td>
                                            <td>";
                                            
                                            // Cek status periksa
                                            if ($row['status_periksa'] === 'sudah diperiksa') {
                                                echo "✅";
                                            } else {
                                                echo "<a href='periksaPasien.php?id={$row['id']}' class='btn btn-success btn-sm'>🩺</a>
                                                      <a href='periksa.php?hapus={$row['id']}' class='btn btn-danger btn-sm' onclick='return confirm(\"Apakah Anda yakin ingin menghapus pasien ini?\")'>🗑️</a>";
                                            }
                                            
                                            echo "</td>
                                        </tr>";
                                    $no++;
                                }
                            }
                            ?>
                        </tbody>
                    </table>
                    <div class="text-center mt-4">
                        <a href="berandaDokter.php" class="btn btn-primary">Kembali ke Dashboard</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <div class="footer">
        <h5>&copy; 2024 Sistem Layanan Kesehatan</h5>
        <p><a href="privacy.php">Kebijakan Privasi</a> | <a href="terms.php">Syarat dan Ketentuan</a></p>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://kit.fontawesome.com/your-font-awesome-kit.js"></script>
</body>
</html>
